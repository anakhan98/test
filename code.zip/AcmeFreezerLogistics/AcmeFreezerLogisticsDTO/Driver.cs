﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsDTO
{
    public class Driver
    {
        public string FName { get; set; }
        public string LName { get; set; }
        public string LNumber { get; set; }
        public DateTime LicExpDate { get; set; }
        public int DriverId { get; set; }




    }
}
