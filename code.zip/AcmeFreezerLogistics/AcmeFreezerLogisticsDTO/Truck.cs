﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsDTO
{
    public class Truck
    {
        public string TruckRegNo { get; set; }
        public DateTime TruckFitExp { get; set; }
        public string TruckModel { get; set; }
        public Decimal TruckHaulCapacity { get; set; }




    }
}
