﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsDTO
{
   public class Sensor
    {
        public int Temp { get; set; }
        public DateTime Date { get; set; }
        public Decimal Lat { get; set; }
        public Decimal Long { get; set; }
        public int DriverID { get; set; }
        public string TruckRN { get; set; }
    }
}
