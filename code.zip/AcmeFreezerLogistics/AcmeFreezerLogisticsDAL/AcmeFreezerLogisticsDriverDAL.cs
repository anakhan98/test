﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsDAL
{
    public class AcmeFreezerLogisticsDriverDAL
    {
        readonly SqlConnection sqlConnectionObject;
        readonly SqlCommand sqlCommandObject;
        readonly string conStr;
        readonly SqlDataAdapter sqlDaObj;



        public AcmeFreezerLogisticsDriverDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["Test"].ToString();
            sqlConnectionObject = new SqlConnection(conStr);
            sqlCommandObject = new SqlCommand();
            sqlDaObj = new SqlDataAdapter();
        }


        public int AddDriver(AcmeFreezerLogisticsDTO.Driver DriverObj)
        {
            try
            {
                sqlCommandObject.CommandText = "usp_AddDriver";
                sqlCommandObject.Connection = sqlConnectionObject;
                sqlCommandObject.Parameters.AddWithValue("@FName", DriverObj.FName);
                sqlCommandObject.Parameters.AddWithValue("@Lname", DriverObj.LName);
                sqlCommandObject.Parameters.AddWithValue("@LiNum", DriverObj.LNumber);
                sqlCommandObject.Parameters.AddWithValue("@ExDate", DriverObj.LicExpDate);
                sqlConnectionObject.Open();
                sqlCommandObject.CommandType = CommandType.StoredProcedure;
                var insertValue = sqlCommandObject.ExecuteNonQuery();
                return insertValue;

            }
            catch (Exception ex)
            {

                return -92;
            }
            finally
            {
                sqlConnectionObject.Close();
            }

        }

        public int AddTruck(AcmeFreezerLogisticsDTO.Truck TruckObj)
        {
            try
            {
                sqlCommandObject.CommandText = "usp_AddTruck";
                sqlCommandObject.Connection = sqlConnectionObject;
                sqlCommandObject.Parameters.AddWithValue("@TruckModel", TruckObj.TruckModel);
                sqlCommandObject.Parameters.AddWithValue("@TruckRegister_Number", TruckObj.TruckRegNo);
                sqlCommandObject.Parameters.AddWithValue("@TruckExpiryDate", TruckObj.TruckFitExp);
                sqlCommandObject.Parameters.AddWithValue("@TruckHaulingCapacity", TruckObj.TruckHaulCapacity);
                sqlConnectionObject.Open();
                sqlCommandObject.CommandType = CommandType.StoredProcedure;
                var insertValue = sqlCommandObject.ExecuteNonQuery();
                return insertValue;

            }
            catch (Exception ex)
            {

                return -92;
            }
            finally
            {
                sqlConnectionObject.Close();
            }

        }


        public int AddSensor(AcmeFreezerLogisticsDTO.Sensor sensorObj)
        {
            try
            {
                sqlCommandObject.CommandText = "usp_AddSensor";
                sqlCommandObject.Connection = sqlConnectionObject;
                sqlCommandObject.Parameters.AddWithValue("@Date", sensorObj.Date);
                sqlCommandObject.Parameters.AddWithValue("@Latitude", sensorObj.Lat);
                sqlCommandObject.Parameters.AddWithValue("@Longitude", sensorObj.Long);
                sqlCommandObject.Parameters.AddWithValue("@DriverID", sensorObj.DriverID);
                sqlCommandObject.Parameters.AddWithValue("@TruckRN", sensorObj.TruckRN);
                sqlConnectionObject.Open();
                sqlCommandObject.CommandType = CommandType.StoredProcedure;
                var insertValue = sqlCommandObject.ExecuteNonQuery();
                return insertValue;

            }
            catch (Exception ex)
            {

                return -92;
            }
            finally
            {
                sqlConnectionObject.Close();
            }

        }

        public int UpdateDlExp(AcmeFreezerLogisticsDTO.Driver driverObj)
        {
            try
            {
                sqlCommandObject.CommandText = "usp_UpdateDLExpiry";
                sqlCommandObject.Connection = sqlConnectionObject;
                sqlCommandObject.Parameters.AddWithValue("@ID", driverObj.DriverId);
                sqlCommandObject.Parameters.AddWithValue("@expdate", driverObj.LicExpDate);
                sqlConnectionObject.Open();
                sqlCommandObject.CommandType = CommandType.StoredProcedure;
                var insertValue = sqlCommandObject.ExecuteNonQuery();
                return insertValue;

            }
            catch (Exception ex)
            {

                return -92;
            }
            finally
            {
                sqlConnectionObject.Close();
            }

        }


        public int UpdateTruckFitExp(AcmeFreezerLogisticsDTO.Truck truckObj)
        {
            try
            {
                sqlCommandObject.CommandText = "usp_UpdateTruckFitExp";
                sqlCommandObject.Connection = sqlConnectionObject;
                sqlCommandObject.Parameters.AddWithValue("@TruckRegNo", truckObj.TruckRegNo);
                sqlCommandObject.Parameters.AddWithValue("@TruckFitExp", truckObj.TruckFitExp);
                sqlConnectionObject.Open();
                sqlCommandObject.CommandType = CommandType.StoredProcedure;
                var insertValue = sqlCommandObject.ExecuteNonQuery();
                return insertValue;

            }
            catch (Exception ex)
            {

                return -92;
            }
            finally
            {
                sqlConnectionObject.Close();
            }

        }

        public List<AcmeFreezerLogisticsDTO.Driver> CheckDriverDAL(int id)
        {

            try
            {
                using (var context = new TruckEntities())
                {
                    var asset = (from item in context.Drivers where item.DriverId == id
                                 select item).ToList();

                  
                    List<AcmeFreezerLogisticsDTO.Driver> itemList = new List<AcmeFreezerLogisticsDTO.Driver>();
                    foreach (var item in asset)
                    {
                        var addObj = new AcmeFreezerLogisticsDTO.Driver
                        {
                            FName = item.FirstName,
                            LName = item.LastName,
                            LNumber = item.LicenseNumber,
                            LicExpDate = Convert.ToDateTime(item.LicenseExpiryDate),
                            DriverId = Convert.ToInt32(item.DriverId)
                        };
                        itemList.Add(addObj);
                    }
                    return itemList;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }










    }
}
