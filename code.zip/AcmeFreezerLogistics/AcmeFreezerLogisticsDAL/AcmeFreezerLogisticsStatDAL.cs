﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsDAL
{
    public class AcmeFreezerLogisticsStatDAL
    {

        //display sensor
        public List<AcmeFreezerLogisticsDTO.Sensor> SensorTracker()
        {

            try
            {
                using (var context = new TruckEntities())
                {
                    var asset = (from item in context.Sensors
                                 select item).ToList();
                    List<AcmeFreezerLogisticsDTO.Sensor> itemList = new List<AcmeFreezerLogisticsDTO.Sensor>();
                    foreach (var item in asset)
                    {
                        var addObj = new AcmeFreezerLogisticsDTO.Sensor
                        {
                            Temp = Convert.ToInt32(item.Temperature),
                            Lat = Convert.ToDecimal(item.Latitude),
                            Long = Convert.ToDecimal(item.Longitude),
                            Date = Convert.ToDateTime(item.Date),
                            DriverID = Convert.ToInt32(item.DriverID),
                            TruckRN = item.TruckRN
                        };
                        itemList.Add(addObj);
                    }
                    return itemList;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        //display truck
        public List<AcmeFreezerLogisticsDTO.Truck> GetTruck()
        {

            try
            {
                using (var context = new TruckEntities())
                {
                    var asset = (from item in context.Trucks
                                 select item).ToList();
                    List<AcmeFreezerLogisticsDTO.Truck> itemList = new List<AcmeFreezerLogisticsDTO.Truck>();
                    foreach (var item in asset)
                    {
                        var addObj = new AcmeFreezerLogisticsDTO.Truck
                        {
                            TruckRegNo = item.TruckRegNo,
                            TruckFitExp = Convert.ToDateTime(item.TruckFitExp),
                            TruckModel = item.TruckModel,
                            TruckHaulCapacity = Convert.ToDecimal(item.TruckHaulCapacity)

                        };
                        itemList.Add(addObj);
                    }
                    return itemList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        //display driver
        public List<AcmeFreezerLogisticsDTO.Driver> GetDriver()
        {

            try
            {
                using (var context = new TruckEntities())
                {
                    var asset = (from item in context.Drivers
                                 select item).ToList();
                    List<AcmeFreezerLogisticsDTO.Driver> itemList = new List<AcmeFreezerLogisticsDTO.Driver>();
                    foreach (var item in asset)
                    {
                        var addObj = new AcmeFreezerLogisticsDTO.Driver
                        {
                            FName = item.FirstName,
                            LName = item.LastName,
                            LNumber = item.LicenseNumber,
                            LicExpDate = Convert.ToDateTime(item.LicenseExpiryDate),
                            DriverId = Convert.ToInt32(item.DriverId)
                        };
                        itemList.Add(addObj);
                    }
                    return itemList;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }











    }
}
