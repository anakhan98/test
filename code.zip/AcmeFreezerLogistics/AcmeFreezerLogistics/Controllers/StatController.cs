﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AcmeFreezerLogistics.Controllers
{
    public class StatController : ApiController
    {
        AcmeFreezerLogisticsBL.AcmeFreezerLogisticsStatBL BLStatObj = new AcmeFreezerLogisticsBL.AcmeFreezerLogisticsStatBL();
        
        //api/acme/stat/getdata
        [ActionName("getdata")]
        [HttpGet]
        public HttpResponseMessage getdata()
        {

            try
            {
                var status = BLStatObj.GetSensors();
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, status);
                return response;
            }
            catch (Exception ex)
            {

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, ex);
                return response;
            }

        }

        //api/acme/stat/getTruck
        [ActionName("getTruck")]
        [HttpGet]
        public HttpResponseMessage GetTruck()
        {

            try
            {
                var status = BLStatObj.GetTrucks();
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, status);
                return response;
            }
            catch (Exception ex)
            {

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, ex);
                return response;
            }

        }


        //api/acme/stat/getDriver
        [ActionName("getDriver")]
        [HttpGet]
        public HttpResponseMessage GetDriver()
        {

            try
            {
                var status = BLStatObj.GetDrivers();
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, status);
                return response;
            }
            catch (Exception ex)
            {

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, ex);
                return response;
            }

        }
    }
}
