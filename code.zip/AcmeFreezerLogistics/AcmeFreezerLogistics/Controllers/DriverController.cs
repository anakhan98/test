﻿using AcmeFreezerLogisticsBL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AcmeFreezerLogistics.Controllers
{
    public class DriverController : ApiController
    {

        AcmeFreezerLogisticsDriverBL DriverBLObj = new AcmeFreezerLogisticsDriverBL();
        /// <summary>
        /// Adds a new driver to the database
        /// </summary>
      

        [ActionName("AddDriver")]
        [HttpPost]
        public HttpResponseMessage AddDriver(AcmeFreezerLogisticsDTO.Driver DriverObj)
        {
            int result = -71;

            try
            {
                result = DriverBLObj.AddDriver(DriverObj);

                return Request.CreateResponse(HttpStatusCode.OK, result);


            }
            catch (Exception ex)
            {

                return Request.CreateResponse(HttpStatusCode.OK, result);

            }

        }


        /// <summary>
        /// Checks whether the driver exists in the database
        /// </summary>
       
        [ActionName("CheckDriver")]
        [HttpGet]
        public HttpResponseMessage CheckDriver(int id)
        {
            //I dont not have time to implement exceptional handling for list. Sorry!!

            var result = DriverBLObj.CheckDriverBL(id);

            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, result);

            return response;

        }



        /// <summary>
        /// Allocates driver to a truck for performing logistics
        /// </summary>
        public void AllocateDriverToTruck()
        {





        }
    }
}
