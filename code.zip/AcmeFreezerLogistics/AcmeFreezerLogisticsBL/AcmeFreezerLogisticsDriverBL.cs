﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsBL
{
    public class AcmeFreezerLogisticsDriverBL
    {
        AcmeFreezerLogisticsDAL.AcmeFreezerLogisticsDriverDAL DalDriverObj = new AcmeFreezerLogisticsDAL.AcmeFreezerLogisticsDriverDAL();

        public int AddDriver(AcmeFreezerLogisticsDTO.Driver deriverObj)
        {
            try
            {
                int resultBL = DalDriverObj.AddDriver(deriverObj);
                return resultBL;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }

        public int AddTruck(AcmeFreezerLogisticsDTO.Truck truckObj)
        {
            try
            {
                int resultBL = DalDriverObj.AddTruck(truckObj);
                return resultBL;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }

        public int AddSensor(AcmeFreezerLogisticsDTO.Sensor sensorObj)
        {
            try
            {
                int resultBL = DalDriverObj.AddSensor(sensorObj);
                return resultBL;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }


        public int UpdateDlExp(AcmeFreezerLogisticsDTO.Driver deriverObj)
        {
            try
            {
                int resultBL = DalDriverObj.UpdateDlExp(deriverObj);
                return resultBL;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }


        public int UpdateTrackExp(AcmeFreezerLogisticsDTO.Truck truckObj)
        {
            try
            {
                int resultBL = DalDriverObj.UpdateTruckFitExp(truckObj);
                return resultBL;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }

        public List<AcmeFreezerLogisticsDTO.Driver> CheckDriverBL(int id)
        {

            try
            {
                var resultBL = DalDriverObj.CheckDriverDAL(id);
                return resultBL;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
