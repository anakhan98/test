﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcmeFreezerLogisticsBL
{
    public class AcmeFreezerLogisticsStatBL
    {

        AcmeFreezerLogisticsDAL.AcmeFreezerLogisticsStatDAL DALStatObj = new AcmeFreezerLogisticsDAL.AcmeFreezerLogisticsStatDAL();
        public List<AcmeFreezerLogisticsDTO.Sensor> GetSensors()
        {

            try
            {
                var resultBL = DALStatObj.SensorTracker();
                return resultBL;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<AcmeFreezerLogisticsDTO.Truck> GetTrucks()
        {

            try
            {
                var resultBL = DALStatObj.GetTruck();
                return resultBL;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<AcmeFreezerLogisticsDTO.Driver> GetDrivers()
        {

            try
            {
                var resultBL = DALStatObj.GetDriver();
                return resultBL;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
